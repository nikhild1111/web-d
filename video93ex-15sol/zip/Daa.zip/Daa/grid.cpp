#include <stdio.h>

int main() {
 int m;
  printf("Enter the value of M\n");
  scanf("%d",&m);
  int s;
   printf("Enter the Size of array \n");
  scanf("%d",&s);
  float arr1[s];
  for(int i=0;i<s;i++)
  {
    printf("Enter the Value of %d item:",i+1);
  scanf("%f", &arr1[i]);
  }
  
  
 
  float arr2[s];
  for(int i=0;i<s;i++)
  {
     printf("Enter the Weight of %d item:",i+1);
  scanf("%f", &arr2[i]);
  }
  float r[s];
  for(int i=0;i<s;i++){
   if (arr2[i] != 0) {
            r[i] = (arr1[i] / arr2[i]);
        } else {
            printf("Error: Division by zero at index %d\n", i);
            return 1; // Exit the program with an error code
        }
    
  }
  float temp;
for(int i=0;i<s-1;i++)
  {
  for(int j=0;j<s-i-1;j++)
  {
  if(r[j]<r[j+1]){
  temp=r[j];
  r[j]=r[j+1];
  r[j+1]=temp;
  
  
  temp=arr2[j];
  arr2[j]=arr2[j+1];
  arr2[j+1]=temp;
  
  temp=arr1[j];
  arr1[j]=arr1[j+1];
  arr1[j+1]=temp;
  }
  }
  }
  float sw=0;
  float sp=0;
  for(int i=0;i<s;i++){
  if(m==sw){
  break;
  }
    if(sw+arr2[i]>m){
         float f=((m-sw)/arr2[i]);
         sw=sw+(arr2[i]*f);
         sp=sp+(arr1[i]*f);
  }  
  else{
     sw=sw+arr2[i];
     sp=sp+arr1[i];
  }
  }
  printf("Maxumun Weight is %f\n  Maxumum Profit is %f",sw,sp);
  
  return 0;
}
