#include<stdio.h>
#include<stdlib.h>

int path[20]; // Path array to store the optimal path
int n;        // Number of cities

int g(int k, int v[], int c[][20]);
void trvpath(int k, int v[], int c[][20], int j);

void main() {
    int mcost;
    path[0] = 0;  // Start from the first city (0-indexed)
    
    printf("Enter value of N:\n");
    scanf("%d", &n);
    
    int c[20][20];  // Cost matrix
    int v[20];      // Visited array
    
    // Initialize visited array
    for(int i = 0; i < n; i++)
        v[i] = 0;

    printf("Enter Array Elements (Cost Matrix):\n");
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            scanf("%d", &c[i][j]);  // Input the cost matrix
        }
    }

    // Display the adjacency (cost) matrix
    printf("Adjacency Matrix:\n");
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            printf("%d\t", c[i][j]);
        }
        printf("\n");
    }

    // Start with the first city (city 0)
    v[0] = 1;  // Mark the first city as visited
    mcost = g(0, v, c);  // Get the minimum cost using the g() function

    // Reset visited array for path calculation
    for(int i = 0; i < n; i++)
        v[i] = 0;
    
    v[0] = 1;  // Start from city 0
    trvpath(0, v, c, 1);  // Traverse the path and construct the solution
    
    printf("Minimum cost is: %d\n", mcost);
    printf("Path: ");
    for(int i = 0; i < n; i++) {
        printf("%d-", path[i] + 1);  // Print the path in 1-indexed format for clarity
    }
    printf("\n");
}

int g(int k, int v[], int c[][20]) {
    int min = 999, temp, flag = 0;

    // Check if all cities have been visited
    for(int i = 1; i < n; i++) {
        if(v[i] == 0)  // If there's an unvisited city
            flag = 1;
    }

    if(flag == 0) {  // All cities visited, return to the starting city
        return c[k][0];  // Cost to return to city 0
    }

    for(int i = 1; i < n; i++) {
        if(v[i] == 0) {  // If city i is unvisited
            v[i] = 1;    // Mark city i as visited
            temp = c[k][i] + g(i, v, c);  // Calculate cost recursively
            if(temp < min) {
                min = temp;  // Update minimum cost
            }
            v[i] = 0;  // Unmark city i for other paths
        }
    }
    
    return min;
}

void trvpath(int k, int v[], int c[][20], int j) {
    int temp, min = 999, t;
    int v1[20];  // Temporary visited array

    if(j < n) {
        for(int i = 1; i < n; i++) {
            if(v[i] == 0) {  // If city i is unvisited
                v[i] = 1;    // Mark city i as visited
                temp = c[k][i] + g(i, v, c);  // Calculate cost recursively
                if(temp < min) {
                    min = temp;  // Update minimum cost
                    t = i;       // Store city with minimum cost
                    for(int k = 0; k < n; k++)
                        v1[k] = v[k];  // Copy visited array
                }
                v[i] = 0;  // Unmark city i
            }
        }
        path[j] = t;  // Update the path with the city
        trvpath(t, v1, c, j + 1);  // Recursive call to the next city
    }
}

